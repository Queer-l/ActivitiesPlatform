-- =============================================
-- 校园活动管理系统 - 种子数据初始化
-- 成员C 第一周任务：初始化角色、账号与示例数据
-- =============================================
-- 功能说明：
--   1. 初始化 2 个系统角色（管理员 / 学生）
--   2. 创建 1 个管理员账号 + 2 个测试学生账号
--   3. 插入 3 条示例活动数据
--   4. 验证并展示初始化结果
-- =============================================
-- 安全提示：
--   ⚠ 正式部署前请立即修改所有默认密码！
--   ⚠ 若后端使用 ASP.NET Core Identity (PBKDF2)，需将 SHA256 哈希迁移为 Identity 格式
-- =============================================

USE CampusActivityDB;
GO


-- *****************************************************
-- 1. 初始化角色数据
-- *****************************************************
-- 系统仅需两个角色：
--   管理员 (RoleId=1): 活动管理、用户管理、数据统计、签到管理
--   学生   (RoleId=2): 浏览活动、在线报名、扫码签到、查看个人记录
-- *****************************************************
-- 实现说明：
--   使用 SET IDENTITY_INSERT ON 显式指定 RoleId=1 和 RoleId=2
--   确保角色ID固定，后端代码可通过常量引用（如 Role.Admin=1, Role.Student=2）
--   使用 IF NOT EXISTS 保证幂等性
-- *****************************************************
IF NOT EXISTS (SELECT 1 FROM Roles WHERE RoleName = N'管理员')
BEGIN
    -- 允许显式插入自增列的值
    SET IDENTITY_INSERT Roles ON;

    INSERT INTO Roles (RoleId, RoleName, Description) VALUES
        (1, N'管理员', N'系统管理员，拥有所有权限：活动管理、用户管理、数据统计'),
        (2, N'学生',   N'普通学生用户：浏览活动、在线报名、扫码签到、查看个人记录');

    -- 恢复自增列行为
    SET IDENTITY_INSERT Roles OFF;
END
GO


-- *****************************************************
-- 2. 初始化管理员账号
-- *****************************************************
-- 默认管理员凭证：
--   用户名: admin
--   密码:   Admin@123456
-- *****************************************************
-- 密码处理说明：
--   使用 HASHBYTES('SHA2_256') 生成 SHA256 哈希
--   LOWER(CONVERT(...)) 将哈希值转为小写 64 位十六进制字符串
--   示例: Admin@123456 → SHA256 → "8c6976e5b5410415bde90bd4dee2560b..."
-- *****************************************************
-- 兼容性说明：
--   如果后端使用 ASP.NET Core Identity 默认的 PBKDF2 算法
--   首次登录时应检测哈希格式，自动升级为 Identity 兼容哈希
--   识别方法：SHA256 哈希为 64 位十六进制字符串
-- *****************************************************
DECLARE @adminRoleId INT = 1;

IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = 'admin')
BEGIN
    INSERT INTO Users (Username, PasswordHash, RealName, Email, Phone, RoleId, IsActive)
    VALUES (
        'admin',
        -- SHA256 哈希：Admin@123456
        LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', N'Admin@123456'), 2)),
        N'系统管理员',
        'admin@campus.edu.cn',
        '13800000000',
        @adminRoleId,
        1
    );
END
GO


-- *****************************************************
-- 3. 初始化测试学生账号
-- *****************************************************
-- 默认学生凭证（所有测试账号密码相同）：
--   用户名格式: student01, student02, ...
--   密码:       Student@123
-- *****************************************************
-- 用途说明：
--   学生01 (张三): 用于测试正常报名、签到流程
--   学生02 (李四): 用于测试黑名单、取消报名等边界场景
-- 后续可扩展更多测试账号（student03, student04...）
-- *****************************************************

-- 测试学生账号 1: 张三
DECLARE @studentRoleId INT = 2;

IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = 'student01')
BEGIN
    INSERT INTO Users (Username, PasswordHash, RealName, Email, Phone, RoleId, IsActive)
    VALUES (
        'student01',
        -- SHA256 哈希：Student@123
        LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', N'Student@123'), 2)),
        N'测试学生张三',
        'student01@campus.edu.cn',
        '13900000001',
        @studentRoleId,
        1
    );
END
GO

-- 测试学生账号 2: 李四
IF NOT EXISTS (SELECT 1 FROM Users WHERE Username = 'student02')
BEGIN
    -- 重新声明变量（因为上一个批次的 GO 结束了作用域）
    DECLARE @studentRoleId2 INT = 2;
    INSERT INTO Users (Username, PasswordHash, RealName, Email, Phone, RoleId, IsActive)
    VALUES (
        'student02',
        -- SHA256 哈希：Student@123
        LOWER(CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', N'Student@123'), 2)),
        N'测试学生李四',
        'student02@campus.edu.cn',
        '13900000002',
        @studentRoleId2,
        1
    );
END
GO


-- *****************************************************
-- 4. 初始化示例活动数据
-- *****************************************************
-- 创建 3 个不同类型的示例活动，覆盖所有活动类别：
--   - 学术类: 2026年校园科技创新大赛
--   - 文体类: 春季校园运动会
--   - 社团类: 校园社团文化节
-- *****************************************************
-- 活动状态说明：
--   Status = 0: 未开始（当前所有示例活动均为该状态）
--   状态由后端定时任务根据 RegistrationDeadline / SignInTime 自动流转
-- *****************************************************
-- 签到窗口说明：
--   SignInStartTime ~ SignInEndTime 定义了允许签到的时间范围
--   扫码签到时，后端需校验当前时间是否在此窗口内
-- *****************************************************

-- 获取管理员用户ID（所有示例活动由 admin 统一创建）
DECLARE @adminUserId INT = (SELECT UserId FROM Users WHERE Username = 'admin');

-- ----------------------------------------------------------
-- 示例活动 1: 科技创新大赛（学术类）
-- 特点: 高参与人数上限(200人)，报名周期长(截止6/15)
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM Activities WHERE Title = N'2026年校园科技创新大赛')
BEGIN
    INSERT INTO Activities (Title, Description, CoverImagePath, Category, Location, MaxParticipants,
                            RegistrationDeadline, SignInStartTime, SignInEndTime,
                            Status, CreatorUserId)
    VALUES (
        N'2026年校园科技创新大赛',
        N'面向全校学生的科技创新竞赛，涵盖人工智能、物联网、软件开发等多个赛道，获奖团队将获得创新创业基金支持。',
        N'/uploads/activities/cover-tech-2026.jpg',
        N'学术',
        N'综合楼A座301报告厅',
        200,
        '2026-06-15 23:59:59',   -- 报名截止：6月15日
        '2026-06-20 08:00:00',   -- 签到开始：6月20日早上8点
        '2026-06-20 18:00:00',   -- 签到结束：6月20日下午6点
        0,                        -- 状态：未开始
        @adminUserId
    );
END
GO

-- ----------------------------------------------------------
-- 示例活动 2: 春季运动会（文体类）
-- 特点: 最大参与人数(500人)，报名即将截止(5/20)
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM Activities WHERE Title = N'春季校园运动会')
BEGIN
    -- 重新声明变量（GO 之后作用域结束）
    DECLARE @adminUserId2 INT = (SELECT UserId FROM Users WHERE Username = 'admin');
    INSERT INTO Activities (Title, Description, CoverImagePath, Category, Location, MaxParticipants,
                            RegistrationDeadline, SignInStartTime, SignInEndTime,
                            Status, CreatorUserId)
    VALUES (
        N'春季校园运动会',
        N'一年一度的春季校园运动会，包含田径、球类等多种体育项目，快来为代表队加油助威！',
        N'/uploads/activities/cover-sports-2026.jpg',
        N'文体',
        N'校体育中心',
        500,
        '2026-05-20 23:59:59',   -- 报名截止：5月20日
        '2026-05-25 07:30:00',   -- 签到开始：5月25日早上7:30
        '2026-05-25 17:00:00',   -- 签到结束：5月25日下午5点
        0,                        -- 状态：未开始
        @adminUserId2
    );
END
GO

-- ----------------------------------------------------------
-- 示例活动 3: 社团文化节（社团类）
-- 特点: 不限人数(800人体验)，大场地(中心广场)
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT 1 FROM Activities WHERE Title = N'校园社团文化节')
BEGIN
    DECLARE @adminUserId3 INT = (SELECT UserId FROM Users WHERE Username = 'admin');
    INSERT INTO Activities (Title, Description, CoverImagePath, Category, Location, MaxParticipants,
                            RegistrationDeadline, SignInStartTime, SignInEndTime,
                            Status, CreatorUserId)
    VALUES (
        N'校园社团文化节',
        N'全校各社团联合展示，包含文艺演出、社团招新、互动游戏等精彩活动，展现校园文化风采。',
        N'/uploads/activities/cover-club-2026.jpg',
        N'社团',
        N'中心广场',
        800,
        '2026-06-01 23:59:59',   -- 报名截止：6月1日
        '2026-06-05 09:00:00',   -- 签到开始：6月5日早上9点
        '2026-06-05 21:00:00',   -- 签到结束：6月5日晚上9点
        0,                        -- 状态：未开始
        @adminUserId3
    );
END
GO


-- *****************************************************
-- 5. 初始化联调业务数据
-- *****************************************************
-- 覆盖接口测试场景：
--   - student01 正常报名并扫码签到
--   - student02 报名后取消，并被加入黑名单
-- *****************************************************

DECLARE @student01Id INT = (SELECT UserId FROM Users WHERE Username = 'student01');
DECLARE @student02Id INT = (SELECT UserId FROM Users WHERE Username = 'student02');
DECLARE @adminId INT = (SELECT UserId FROM Users WHERE Username = 'admin');
DECLARE @techActivityId INT = (SELECT ActivityId FROM Activities WHERE Title = N'2026年校园科技创新大赛');
DECLARE @sportsActivityId INT = (SELECT ActivityId FROM Activities WHERE Title = N'春季校园运动会');

IF @student01Id IS NOT NULL AND @techActivityId IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM Registrations WHERE UserId = @student01Id AND ActivityId = @techActivityId)
BEGIN
    INSERT INTO Registrations (UserId, ActivityId, RegistrationTime, Status)
    VALUES (@student01Id, @techActivityId, '2026-05-10 14:30:00', 0);
END

IF @student02Id IS NOT NULL AND @techActivityId IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM Registrations WHERE UserId = @student02Id AND ActivityId = @techActivityId)
BEGIN
    INSERT INTO Registrations (UserId, ActivityId, RegistrationTime, Status)
    VALUES (@student02Id, @techActivityId, '2026-05-11 09:10:00', 1);
END

IF @student01Id IS NOT NULL AND @sportsActivityId IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM Registrations WHERE UserId = @student01Id AND ActivityId = @sportsActivityId)
BEGIN
    INSERT INTO Registrations (UserId, ActivityId, RegistrationTime, Status)
    VALUES (@student01Id, @sportsActivityId, '2026-05-12 16:20:00', 0);
END
GO

DECLARE @student01Id2 INT = (SELECT UserId FROM Users WHERE Username = 'student01');
DECLARE @techActivityId2 INT = (SELECT ActivityId FROM Activities WHERE Title = N'2026年校园科技创新大赛');
DECLARE @registrationId INT = (
    SELECT RegistrationId
    FROM Registrations
    WHERE UserId = @student01Id2 AND ActivityId = @techActivityId2
);

IF @registrationId IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM CheckIns WHERE UserId = @student01Id2 AND ActivityId = @techActivityId2)
BEGIN
    INSERT INTO CheckIns (RegistrationId, UserId, ActivityId, CheckInTime, CheckInType, Remark)
    VALUES (@registrationId, @student01Id2, @techActivityId2, '2026-06-20 09:15:00', 0, N'扫码签到测试数据');
END
GO

DECLARE @student02Id2 INT = (SELECT UserId FROM Users WHERE Username = 'student02');
DECLARE @adminId2 INT = (SELECT UserId FROM Users WHERE Username = 'admin');

IF @student02Id2 IS NOT NULL AND @adminId2 IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM Blacklist WHERE UserId = @student02Id2 AND ActivityId IS NULL AND IsActive = 1)
BEGIN
    INSERT INTO Blacklist (UserId, ActivityId, Reason, BlockedAt, BlockedByUserId, IsActive)
    VALUES (@student02Id2, NULL, N'联调测试：模拟多次无故缺席活动', '2026-05-13 10:00:00', @adminId2, 1);
END
GO


-- *****************************************************
-- 6. 验证初始化结果
-- *****************************************************
-- 依次展示三张核心表的初始化数据，确认脚本执行正确
-- *****************************************************

PRINT N'';
PRINT N'============= 数据初始化结果验证 =============';
PRINT N'';

-- 验证角色数据（预期：2条记录）
PRINT N'▶ 角色列表（预期 2 条：管理员、学生）';
SELECT RoleId, RoleName, Description FROM Roles;

PRINT N'';
-- 验证用户数据（预期：3条记录）
PRINT N'▶ 用户列表（预期 3 条：admin, student01, student02）';
SELECT UserId, Username, RealName, RoleId, IsActive FROM Users;

PRINT N'';
-- 验证活动数据（预期：3条记录）
PRINT N'▶ 活动列表（预期 3 条：创新大赛、运动会、文化节）';
SELECT ActivityId, Title, Category, Status, MaxParticipants, CoverImagePath FROM Activities;

PRINT N'';
PRINT N'▶ 联调业务数据（报名、签到、黑名单）';
SELECT 'Registrations' AS TableName, COUNT(*) AS RowCount FROM Registrations
UNION ALL SELECT 'CheckIns', COUNT(*) FROM CheckIns
UNION ALL SELECT 'Blacklist', COUNT(*) FROM Blacklist;

PRINT N'';
PRINT N'============================================';
PRINT N'  ⚠ 默认账号密码（正式部署前请修改）：';
PRINT N'    管理员账号: admin       / Admin@123456';
PRINT N'    测试学生1:  student01   / Student@123';
PRINT N'    测试学生2:  student02   / Student@123';
PRINT N'';
PRINT N'  ⚠ 密码存储方式：SHA256 哈希';
PRINT N'    若后端使用 ASP.NET Core Identity (PBKDF2)，';
PRINT N'    需在首次登录时自动升级哈希格式。';
PRINT N'';
PRINT N'  ⚠ 种子数据初始化完成！可进入第二周联调测试。';
PRINT N'============================================';
GO
