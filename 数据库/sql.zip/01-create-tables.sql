-- =============================================
-- 校园活动管理系统 - 数据库与表结构创建
-- 成员C 第一周任务：数据库设计
-- =============================================
-- 功能说明：
--   1. 创建 CampusActivityDB 数据库
--   2. 创建 6 张核心业务表（Roles, Users, Activities, Registrations, CheckIns, Blacklist）
--   3. 定义主键、外键、唯一约束、检查约束
-- =============================================
-- 执行方式：
--   - 在 SSMS 中按 F5 直接执行
--   - 或在 VS Code 中启用 SQLCMD 模式后执行
-- =============================================
-- 数据库设计说明：
--   字符集统一使用 NVARCHAR（支持中英混合存储）
--   主键统一使用 INT IDENTITY 自增
--   时间字段统一使用 DATETIME 类型，默认值 GETDATE()
--   外键策略：Registrations→Activities 级联删除；Blacklist→Activities SET NULL
-- =============================================


-- *****************************************************
-- 1. 创建数据库
-- *****************************************************
-- 数据库名称: CampusActivityDB
-- 用途: 校园活动报名与签到管理系统所有业务数据
-- 字符集: 使用 SQL Server 默认排序规则（支持中文）
-- 说明: 使用 IF NOT EXISTS 确保脚本可重复执行（幂等性）
-- *****************************************************
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'CampusActivityDB')
BEGIN
    CREATE DATABASE CampusActivityDB;
END
GO

-- 切换到目标数据库
USE CampusActivityDB;
GO


-- *****************************************************
-- 2. 角色表（Roles）
-- *****************************************************
-- 用途: 存储系统角色（管理员 / 学生），用于 RBAC 权限控制
-- 角色数量: 极少（<10条），无需额外索引
-- 外键关系: 被 Users 表引用（RoleId）
-- *****************************************************
-- 字段说明:
--   RoleId      角色ID      主键，自增（IDENTITY(1,1)）
--   RoleName    角色名称    NVARCHAR(50)，唯一约束，不允许重复
--   Description 角色描述    NVARCHAR(200)，可为空
--   CreatedAt   创建时间    DATETIME，默认当前时间
-- *****************************************************
-- 种子数据:
--   (1, '管理员', '系统管理员')
--   (2, '学生',   '普通学生用户')
-- *****************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Roles') AND type = 'U')
BEGIN
    CREATE TABLE Roles (
        RoleId          INT IDENTITY(1,1)   NOT NULL,   -- 角色ID，主键，从1开始自增
        RoleName        NVARCHAR(50)        NOT NULL,   -- 角色名称：管理员 / 学生
        Description     NVARCHAR(200)       NULL,       -- 角色描述，辅助说明
        CreatedAt       DATETIME            NOT NULL DEFAULT GETDATE(),  -- 创建时间

        -- 主键约束：聚集索引在 RoleId 上（默认）
        CONSTRAINT PK_Roles PRIMARY KEY CLUSTERED (RoleId),
        -- 唯一约束：角色名称不能重复（防止重复插入"管理员""学生"）
        CONSTRAINT UQ_Roles_RoleName UNIQUE (RoleName)
    );
END
GO


-- *****************************************************
-- 3. 用户表（Users）
-- *****************************************************
-- 用途: 存储所有系统用户（管理员 + 学生），是系统最核心的表
-- 数据量: 预估数千至数万条（全校学生规模）
-- 安全: 密码使用 SHA256 哈希存储，不存储明文
-- 外键关系:
--   RoleId → Roles(RoleId)  每个用户必须属于一个角色
-- 被引用关系:
--   Users → Activities (CreatorUserId)
--   Users → Registrations (UserId)
--   Users → CheckIns (UserId)
--   Users → Blacklist (UserId, BlockedByUserId)
-- *****************************************************
-- 字段说明:
--   UserId       用户ID       主键，自增
--   Username     用户名       NVARCHAR(50)，唯一，用于登录
--   PasswordHash 密码哈希     NVARCHAR(256)，SHA256 哈希值（64位16进制字符串）
--   RealName     真实姓名     NVARCHAR(50)，用于显示和签到校验
--   Email        邮箱         NVARCHAR(100)，唯一，格式校验，可为空
--   Phone        手机号       NVARCHAR(20)，可为空
--   RoleId       角色ID       INT，外键→Roles，默认2（学生）
--   IsActive     是否激活     BIT，1=激活 0=禁用（可停用违规用户）
--   CreatedAt    注册时间     DATETIME，默认当前时间
-- *****************************************************
-- 约束说明:
--   UQ_Users_Username: 用户名唯一（登录凭证）
--   UQ_Users_Email:    邮箱唯一（找回密码凭证）
--   CK_Users_Email:    邮箱格式校验（含 @ 符号和域名）
--   FK_Users_Roles:    角色外键（ON DELETE NO ACTION 防止误删角色导致用户孤立）
-- *****************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Users') AND type = 'U')
BEGIN
    CREATE TABLE Users (
        UserId          INT IDENTITY(1,1)   NOT NULL,   -- 用户ID，主键
        Username        NVARCHAR(50)        NOT NULL,   -- 用户名，登录凭据
        PasswordHash    NVARCHAR(256)       NOT NULL,   -- 密码哈希（SHA256，64位16进制）
        RealName        NVARCHAR(50)        NOT NULL,   -- 真实姓名
        Email           NVARCHAR(100)       NULL,       -- 邮箱（可为空，但如有值必须唯一）
        Phone           NVARCHAR(20)        NULL,       -- 手机号（可选）
        RoleId          INT                 NOT NULL DEFAULT 2,    -- 角色ID，默认2=学生
        IsActive        BIT                 NOT NULL DEFAULT 1,    -- 是否激活，默认1=激活
        CreatedAt       DATETIME            NOT NULL DEFAULT GETDATE(),  -- 注册时间

        -- 主键约束
        CONSTRAINT PK_Users PRIMARY KEY CLUSTERED (UserId),
        -- 唯一约束：用户名不可重复
        CONSTRAINT UQ_Users_Username UNIQUE (Username),
        -- 唯一约束：邮箱不可重复（NULL值不参与唯一检查）
        CONSTRAINT UQ_Users_Email UNIQUE (Email),
        -- 外键约束：RoleId 关联 Roles 表
        CONSTRAINT FK_Users_Roles FOREIGN KEY (RoleId)
            REFERENCES Roles(RoleId)
            ON DELETE NO ACTION     -- 角色被删除时阻止操作，保护数据完整性
            ON UPDATE NO ACTION,
        -- 检查约束：邮箱格式基本校验（必须有 @ 符号和域名）
        CONSTRAINT CK_Users_Email CHECK (Email IS NULL OR Email LIKE '%_@_%._%')
    );
END
GO


-- *****************************************************
-- 4. 活动表（Activities）
-- *****************************************************
-- 用途: 存储所有校园活动信息，是业务核心表
-- 数据量: 预估每学期数百条活动
-- 状态机: 0=未开始 → 1=进行中 → 2=已结束（由后端定时任务自动流转）
-- 外键关系:
--   CreatorUserId → Users(UserId)  每个活动必有一个创建者
-- 被引用关系:
--   Activities → Registrations (ActivityId)  级联删除
--   Activities → CheckIns (ActivityId)       级联删除
--   Activities → Blacklist (ActivityId)      SET NULL
-- *****************************************************
-- 字段说明:
--   ActivityId            活动ID          主键，自增
--   Title                 活动标题        NVARCHAR(200)，不可为空
--   Description           活动描述        NVARCHAR(MAX)，富文本，可为空
--   CoverImagePath        封面图路径      NVARCHAR(500)，服务器文件路径
--   Category              活动类别        NVARCHAR(50)：学术/文体/社团，默认'其他'
--   Location              活动地点        NVARCHAR(200)，不可为空
--   MaxParticipants       最大参与人数    INT，0=不限人数
--   RegistrationDeadline  报名截止时间    DATETIME，截止后不再接受报名
--   SignInStartTime       签到开始时间    DATETIME，可为空（活动取消时）
--   SignInEndTime         签到结束时间    DATETIME，可为空
--   Status                活动状态        TINYINT：0=未开始 1=进行中 2=已结束
--   CreatorUserId         创建者ID        INT，外键→Users
--   CreatedAt             创建时间        DATETIME
--   UpdatedAt             更新时间        DATETIME，记录最后修改时间
-- *****************************************************
-- 约束说明:
--   CK_MaxParticipants:   最大参与人数 >= 0（0 表示不限制）
--   CK_Deadline:          报名截止时间必须晚于当前时间（仅对未开始活动）
--   CK_SignInTime:        签到开始时间必须早于签到结束时间
-- *****************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Activities') AND type = 'U')
BEGIN
    CREATE TABLE Activities (
        ActivityId              INT IDENTITY(1,1)   NOT NULL,   -- 活动ID，主键
        Title                   NVARCHAR(200)       NOT NULL,   -- 活动标题
        Description             NVARCHAR(MAX)       NULL,       -- 活动详细描述（支持长文本）
        CoverImagePath          NVARCHAR(500)       NULL,       -- 封面图片在服务器上的存储路径
        Category                NVARCHAR(50)        NOT NULL DEFAULT N'其他',  -- 活动类别
        Location                NVARCHAR(200)       NOT NULL,   -- 活动举办地点
        MaxParticipants         INT                 NOT NULL DEFAULT 0,    -- 最大参与人数，0=不限
        RegistrationDeadline    DATETIME            NOT NULL,   -- 报名截止时间
        SignInStartTime         DATETIME            NULL,       -- 签到开始时间
        SignInEndTime           DATETIME            NULL,       -- 签到结束时间
        Status                  TINYINT             NOT NULL DEFAULT 0,    -- 活动状态
        CreatorUserId           INT                 NOT NULL,   -- 创建者用户ID
        CreatedAt               DATETIME            NOT NULL DEFAULT GETDATE(),  -- 创建时间
        UpdatedAt               DATETIME            NOT NULL DEFAULT GETDATE(),  -- 最后更新时间

        -- 主键约束
        CONSTRAINT PK_Activities PRIMARY KEY CLUSTERED (ActivityId),
        -- 外键约束：创建者关联用户表
        CONSTRAINT FK_Activities_Users FOREIGN KEY (CreatorUserId)
            REFERENCES Users(UserId)
            ON DELETE NO ACTION,    -- 用户删除时阻止操作
        -- 检查约束：最大参与人数不能为负数
        CONSTRAINT CK_Activities_MaxParticipants CHECK (MaxParticipants >= 0),
        -- 检查约束：签到时间范围合法性（开始时间 < 结束时间）
        CONSTRAINT CK_Activities_SignInTime CHECK (
            SignInStartTime IS NULL OR SignInEndTime IS NULL OR SignInStartTime < SignInEndTime
        ),
        -- 检查约束：活动状态只能取 0=未开始、1=进行中、2=已结束
        CONSTRAINT CK_Activities_Status CHECK (Status IN (0, 1, 2))
    );
END
GO


-- *****************************************************
-- 5. 报名表（Registrations）
-- *****************************************************
-- 用途: 记录用户对活动的报名信息，是活动与用户的多对多关联表
-- 数据量: 预估数万条（每学期活动 × 参与人数）
-- 业务规则:
--   - 一个用户对同一活动只能报名一次（唯一约束）
--   - 活动满员后不能再报名（由后端在插入前校验）
--   - 黑名单用户不能报名（由后端在插入前校验）
--   - 报名截止后不能再报名（由后端校验）
-- 外键关系:
--   UserId     → Users(UserId)
--   ActivityId → Activities(ActivityId)  级联删除（删除活动时自动删除报名记录）
-- 被引用关系:
--   Registrations → CheckIns (RegistrationId)  签到必须关联报名
-- *****************************************************
-- 字段说明:
--   RegistrationId   报名ID       主键，自增
--   UserId           用户ID       INT，外键→Users
--   ActivityId       活动ID       INT，外键→Activities（级联删除）
--   RegistrationTime 报名时间     DATETIME，默认当前时间
--   Status           报名状态     TINYINT：0=已报名 1=已取消（软删除，保留记录）
-- *****************************************************
-- 约束说明:
--   UQ_Registrations_UserActivity: 联合唯一（UserId + ActivityId），防止重复报名
--   FK_Registrations_Activities:   ON DELETE CASCADE（活动删除则报名记录连带删除）
-- *****************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Registrations') AND type = 'U')
BEGIN
    CREATE TABLE Registrations (
        RegistrationId  INT IDENTITY(1,1)   NOT NULL,   -- 报名ID，主键
        UserId          INT                 NOT NULL,   -- 报名用户ID
        ActivityId      INT                 NOT NULL,   -- 报名活动ID
        RegistrationTime DATETIME           NOT NULL DEFAULT GETDATE(),  -- 报名时间
        Status          TINYINT             NOT NULL DEFAULT 0,    -- 0=已报名 1=已取消

        -- 主键约束
        CONSTRAINT PK_Registrations PRIMARY KEY CLUSTERED (RegistrationId),
        -- 外键约束：报名用户
        CONSTRAINT FK_Registrations_Users FOREIGN KEY (UserId)
            REFERENCES Users(UserId),
        -- 外键约束：报名活动（级联删除：删除活动时自动清除报名记录）
        CONSTRAINT FK_Registrations_Activities FOREIGN KEY (ActivityId)
            REFERENCES Activities(ActivityId)
            ON DELETE CASCADE,
        -- 唯一约束：一个用户对一个活动只能有一条报名记录
        CONSTRAINT UQ_Registrations_UserActivity UNIQUE (UserId, ActivityId),
        -- 检查约束：报名状态只能取 0=已报名、1=已取消
        CONSTRAINT CK_Registrations_Status CHECK (Status IN (0, 1))
    );
END
GO


-- *****************************************************
-- 6. 签到表（CheckIns）
-- *****************************************************
-- 用途: 记录活动签到信息，支持扫码签到和手动补签两种方式
-- 数据量: 与报名记录数相当（每个报名对应一条签到）
-- 业务规则:
--   - 扫码签到: RegistrationId 必须有值（先报名才能扫码签到）
--   - 手动补签: RegistrationId 可为 NULL（管理员权限操作）
--   - 签到时间必须在签到窗口内（由后端校验）
--   - 同一报名记录只能签到一次（由后端校验）
-- 外键关系:
--   RegistrationId → Registrations(RegistrationId)  可为空（补签场景）
--   UserId         → Users(UserId)
--   ActivityId     → Activities(ActivityId)  级联删除
-- *****************************************************
-- 字段说明:
--   CheckInId       签到ID       主键，自增
--   RegistrationId  报名ID       INT，外键→Registrations，可为空（手动补签时为空）
--   UserId          用户ID       INT，外键→Users
--   ActivityId      活动ID       INT，外键→Activities（级联删除）
--   CheckInTime     签到时间     DATETIME，默认当前时间
--   CheckInType     签到方式     TINYINT：0=扫码签到 1=手动补签
--   Remark          备注         NVARCHAR(500)，补签原因等说明
-- *****************************************************
-- 关联逻辑:
--   扫码签到流程:  用户报名 → 获得二维码 → 管理员扫码 → 写入CheckIns（带RegistrationId）
--   手动补签流程:  管理员操作 → 跳过报名关联 → 直接写入CheckIns（RegistrationId=NULL）
-- *****************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'CheckIns') AND type = 'U')
BEGIN
    CREATE TABLE CheckIns (
        CheckInId       INT IDENTITY(1,1)   NOT NULL,   -- 签到ID，主键
        RegistrationId  INT                 NULL,       -- 关联的报名ID（补签时可为空）
        UserId          INT                 NOT NULL,   -- 签到用户ID
        ActivityId      INT                 NOT NULL,   -- 签到活动ID
        CheckInTime     DATETIME            NOT NULL DEFAULT GETDATE(),  -- 签到时间
        CheckInType     TINYINT             NOT NULL DEFAULT 0,    -- 0=扫码签到 1=手动补签
        Remark          NVARCHAR(500)       NULL,       -- 备注（补签原因、异常说明等）

        -- 主键约束
        CONSTRAINT PK_CheckIns PRIMARY KEY CLUSTERED (CheckInId),
        -- 外键约束：关联报名记录（补签时可为空，因此允许 NULL）
        CONSTRAINT FK_CheckIns_Registrations FOREIGN KEY (RegistrationId)
            REFERENCES Registrations(RegistrationId),
        -- 外键约束：签到用户
        CONSTRAINT FK_CheckIns_Users FOREIGN KEY (UserId)
            REFERENCES Users(UserId),
        -- 外键约束：签到活动（级联删除：活动删除则签到记录连带删除）
        CONSTRAINT FK_CheckIns_Activities FOREIGN KEY (ActivityId)
            REFERENCES Activities(ActivityId)
            ON DELETE CASCADE,
        -- 防止同一活动同一用户重复签到；与手动补签场景兼容
        CONSTRAINT UQ_CheckIns_UserActivity UNIQUE (UserId, ActivityId),
        -- 检查约束：签到方式只能取 0=扫码签到、1=手动补签
        CONSTRAINT CK_CheckIns_CheckInType CHECK (CheckInType IN (0, 1))
    );
END
GO


-- *****************************************************
-- 7. 黑名单表（Blacklist）
-- *****************************************************
-- 用途: 管理违规用户，支持全局拉黑和针对特定活动的拉黑
-- 数据量: 极少（仅违规用户）
-- 业务规则:
--   - ActivityId = NULL: 全局拉黑（该用户不能报名任何活动）
--   - ActivityId ≠ NULL: 针对特定活动的拉黑（该用户不能报名指定活动）
--   - IsActive = 0: 拉黑已解除（保留历史记录用于审计）
-- 外键关系:
--   UserId          → Users(UserId)        被拉黑的用户
--   BlockedByUserId → Users(UserId)        执行拉黑操作的管理员
--   ActivityId      → Activities(ActivityId)  可选，SET NULL（活动删除时保留记录）
-- *****************************************************
-- 字段说明:
--   BlacklistId     黑名单ID      主键，自增
--   UserId          被拉黑用户ID   INT，外键→Users
--   ActivityId      活动ID         INT，可为空（NULL=全局拉黑），外键→Activities
--   Reason          拉黑原因       NVARCHAR(500)，必填（审计需要）
--   BlockedAt       拉黑时间       DATETIME，默认当前时间
--   BlockedByUserId 操作人ID       INT，外键→Users（记录谁执行了拉黑操作）
--   IsActive        是否生效       BIT，1=生效中 0=已解除
-- *****************************************************
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'Blacklist') AND type = 'U')
BEGIN
    CREATE TABLE Blacklist (
        BlacklistId     INT IDENTITY(1,1)   NOT NULL,   -- 黑名单记录ID，主键
        UserId          INT                 NOT NULL,   -- 被拉黑的用户ID
        ActivityId      INT                 NULL,       -- 活动ID（NULL=全局拉黑，所有活动生效）
        Reason          NVARCHAR(500)       NOT NULL,   -- 拉黑原因（必填，审计追溯）
        BlockedAt       DATETIME            NOT NULL DEFAULT GETDATE(),  -- 拉黑操作时间
        BlockedByUserId INT                 NOT NULL,   -- 执行拉黑操作的管理员ID
        IsActive        BIT                 NOT NULL DEFAULT 1,    -- 是否生效（1=生效 0=已解除）

        -- 主键约束
        CONSTRAINT PK_Blacklist PRIMARY KEY CLUSTERED (BlacklistId),
        -- 外键约束：被拉黑的用户
        CONSTRAINT FK_Blacklist_Users_User FOREIGN KEY (UserId)
            REFERENCES Users(UserId),
        -- 外键约束：执行拉黑操作的管理员
        CONSTRAINT FK_Blacklist_Users_BlockedBy FOREIGN KEY (BlockedByUserId)
            REFERENCES Users(UserId),
        -- 外键约束：关联的活动（SET NULL：活动被删除后保留黑名单记录）
        CONSTRAINT FK_Blacklist_Activities FOREIGN KEY (ActivityId)
            REFERENCES Activities(ActivityId)
            ON DELETE SET NULL
    );
END
GO


-- 打印完成信息
PRINT N'============================================';
PRINT N'  所有核心表创建完成！';
PRINT N'  共创建 6 张表：';
PRINT N'    1. Roles          - 角色表';
PRINT N'    2. Users          - 用户表';
PRINT N'    3. Activities     - 活动表';
PRINT N'    4. Registrations  - 报名表';
PRINT N'    5. CheckIns       - 签到表';
PRINT N'    6. Blacklist      - 黑名单表';
PRINT N'============================================';
GO
