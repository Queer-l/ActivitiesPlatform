-- =============================================
-- 校园活动管理系统 - 一键建库脚本（SQLCMD 模式）
-- 成员C 数据库交付主入口
-- =============================================
-- 执行方式：
--   1. SSMS：菜单 Query -> SQLCMD Mode，然后执行本文件
--   2. 命令行：sqlcmd -S localhost -E -i sql\00-run-all.sql
-- =============================================

PRINT N'============================================';
PRINT N'  CampusActivityDB 初始化开始';
PRINT N'============================================';
GO

:r .\sql\01-create-tables.sql
:r .\sql\02-create-indexes.sql
:r .\sql\03-seed-data.sql
:r .\sql\06-member-c-qa-checks.sql

PRINT N'============================================';
PRINT N'  CampusActivityDB 初始化与验证完成';
PRINT N'============================================';
GO
