-- =============================================
-- 校园活动管理系统 - 成员C 数据库 QA 验证脚本
-- =============================================
-- 用途：
--   快速检查表结构、约束、索引、种子数据和核心业务一致性。
-- =============================================

USE CampusActivityDB;
GO

PRINT N'1. 核心表数量（预期 6 张）';
SELECT TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
  AND TABLE_NAME IN ('Roles','Users','Activities','Registrations','CheckIns','Blacklist')
ORDER BY TABLE_NAME;

PRINT N'2. 约束清单';
SELECT
    o.name AS TableName,
    kc.name AS ConstraintName,
    kc.type_desc AS ConstraintType
FROM sys.key_constraints kc
JOIN sys.objects o ON kc.parent_object_id = o.object_id
WHERE o.name IN ('Roles','Users','Activities','Registrations','CheckIns','Blacklist')
UNION ALL
SELECT
    o.name,
    fk.name,
    fk.type_desc
FROM sys.foreign_keys fk
JOIN sys.objects o ON fk.parent_object_id = o.object_id
WHERE o.name IN ('Roles','Users','Activities','Registrations','CheckIns','Blacklist')
UNION ALL
SELECT
    o.name,
    cc.name,
    'CHECK_CONSTRAINT'
FROM sys.check_constraints cc
JOIN sys.objects o ON cc.parent_object_id = o.object_id
WHERE o.name IN ('Roles','Users','Activities','Registrations','CheckIns','Blacklist')
ORDER BY TableName, ConstraintName;

PRINT N'3. 非聚集索引清单';
SELECT
    OBJECT_NAME(object_id) AS TableName,
    name AS IndexName,
    type_desc AS IndexType,
    has_filter,
    filter_definition
FROM sys.indexes
WHERE object_id IN (
    OBJECT_ID('Roles'), OBJECT_ID('Users'), OBJECT_ID('Activities'),
    OBJECT_ID('Registrations'), OBJECT_ID('CheckIns'), OBJECT_ID('Blacklist')
)
  AND is_primary_key = 0
  AND is_unique_constraint = 0
ORDER BY TableName, IndexName;

PRINT N'4. 种子数据概览';
SELECT 'Roles' AS TableName, COUNT(*) AS RowCount FROM Roles
UNION ALL SELECT 'Users', COUNT(*) FROM Users
UNION ALL SELECT 'Activities', COUNT(*) FROM Activities
UNION ALL SELECT 'Registrations', COUNT(*) FROM Registrations
UNION ALL SELECT 'CheckIns', COUNT(*) FROM CheckIns
UNION ALL SELECT 'Blacklist', COUNT(*) FROM Blacklist;

PRINT N'5. 报名与签到一致性检查（预期无结果）';
SELECT ci.*
FROM CheckIns ci
LEFT JOIN Registrations r
    ON r.UserId = ci.UserId
   AND r.ActivityId = ci.ActivityId
   AND r.Status = 0
WHERE ci.CheckInType = 0
  AND r.RegistrationId IS NULL;

PRINT N'6. 活动报名人数与签到人数统计';
SELECT
    a.ActivityId,
    a.Title,
    COUNT(DISTINCT CASE WHEN r.Status = 0 THEN r.RegistrationId END) AS RegisteredCount,
    COUNT(DISTINCT ci.CheckInId) AS CheckedInCount,
    CAST(
        CASE
            WHEN COUNT(DISTINCT CASE WHEN r.Status = 0 THEN r.RegistrationId END) = 0 THEN 0
            ELSE COUNT(DISTINCT ci.CheckInId) * 100.0 /
                 COUNT(DISTINCT CASE WHEN r.Status = 0 THEN r.RegistrationId END)
        END AS DECIMAL(5,2)
    ) AS CheckInRate
FROM Activities a
LEFT JOIN Registrations r ON r.ActivityId = a.ActivityId
LEFT JOIN CheckIns ci ON ci.ActivityId = a.ActivityId
GROUP BY a.ActivityId, a.Title
ORDER BY a.ActivityId;
GO
