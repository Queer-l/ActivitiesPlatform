-- =============================================
-- 校园活动管理系统 - 数据库验证查询
-- =============================================
-- 用途: 快速验证数据库表结构是否创建成功
-- =============================================

-- 切换到目标数据库
USE CampusActivityDB;
GO
-- 查询所有用户表（BASE TABLE），排除系统表和视图
-- 预期结果: 6 张表（Roles, Users, Activities, Registrations, CheckIns, Blacklist）
SELECT
    TABLE_SCHEMA   AS 架构,
    TABLE_NAME     AS 表名,
    TABLE_TYPE     AS 类型
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;
GO


-- =============================================
-- 查看表结构 — 4 种方式（选一种执行即可）
-- =============================================

-- 方式1: sp_help — 最详细（列信息、索引、约束一览）
EXEC sp_help 'Users';
GO

-- 方式2: INFORMATION_SCHEMA.COLUMNS — 列清单（可筛选）
SELECT
    COLUMN_NAME         AS 列名,
    DATA_TYPE           AS 数据类型,
    CHARACTER_MAXIMUM_LENGTH AS 最大长度,
    IS_NULLABLE         AS 允许空,
    COLUMN_DEFAULT      AS 默认值
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Users'
ORDER BY ORDINAL_POSITION;
GO

-- 方式3: sys.columns — 含主键标记
SELECT
    c.name              AS 列名,
    t.name              AS 数据类型,
    c.max_length        AS 最大长度,
    c.is_nullable       AS 允许空,
    CASE WHEN pk.column_id IS NOT NULL THEN 'PK' ELSE '' END AS 键
FROM sys.columns c
JOIN sys.types t ON c.user_type_id = t.user_type_id
LEFT JOIN (
    SELECT ic.column_id
    FROM sys.index_columns ic
    JOIN sys.indexes i ON ic.object_id = i.object_id AND ic.index_id = i.index_id
    WHERE i.is_primary_key = 1 AND i.object_id = OBJECT_ID('Users')
) pk ON c.column_id = pk.column_id
WHERE c.object_id = OBJECT_ID('Users')
ORDER BY c.column_id;
GO

-- 方式4: 一次性查看所有表的列（全库概览）
SELECT
    TABLE_NAME          AS 表名,
    COLUMN_NAME         AS 列名,
    DATA_TYPE           AS 类型,
    IS_NULLABLE         AS 允许空
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME IN ('Roles','Users','Activities','Registrations','CheckIns','Blacklist')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
GO


-- =============================================
-- 查看当前所有登录账号
-- =============================================
-- 用途: 查看 SQL Server 实例的所有登录名、数据库用户及其权限
-- 在创建新账号前后执行，确认账号是否已存在或创建成功
-- =============================================

-- 查询1: 服务器级登录名（所有登录名）
SELECT
    name              AS 登录名,
    type_desc         AS 登录类型,
    is_disabled       AS 是否禁用,
    create_date       AS 创建时间,
    default_database_name AS 默认数据库
FROM sys.server_principals
WHERE type IN ('S', 'U', 'G')   -- S=SQL登录 U=Windows登录 G=Windows组
  AND name NOT LIKE '##%'       -- 排除系统账号
ORDER BY type_desc, name;

-- 查询2: CampusActivityDB 数据库用户（仅当前库）
SELECT
    dp.name           AS 数据库用户名,
    dp.type_desc      AS 用户类型,
    r.name            AS 所属角色,
    sp.name           AS 服务器登录名
FROM sys.database_principals dp
LEFT JOIN sys.database_role_members rm ON dp.principal_id = rm.member_principal_id
LEFT JOIN sys.database_principals r ON rm.role_principal_id = r.principal_id
LEFT JOIN sys.server_principals sp ON dp.sid = sp.sid
WHERE dp.type IN ('S', 'U')
  AND dp.name NOT IN ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys')
ORDER BY dp.name;
GO

-- =============================================
-- 创建远程连接登录账号
-- =============================================
-- 用途: 为后端开发者创建 SQL Server 认证账号，用于远程连接数据库
-- 执行方式: 在 SSMS 中以管理员身份执行此段（需要 sysadmin 权限）
-- =============================================

-- 1. 创建服务器登录名
USE master;
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = 'CampusApp')
BEGIN
    CREATE LOGIN CampusApp
        WITH PASSWORD = '111111',  -- 正式部署前修改此密码
        CHECK_POLICY = OFF,               -- 不强制密码策略（开发环境）
        DEFAULT_DATABASE = CampusActivityDB;
END
GO

-- 2. 映射到 CampusActivityDB 并授权
USE CampusActivityDB;
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'CampusApp')
BEGIN
    CREATE USER CampusApp FOR LOGIN CampusApp;
    ALTER ROLE db_datareader ADD MEMBER CampusApp;   -- 读取数据
    ALTER ROLE db_datawriter ADD MEMBER CampusApp;   -- 写入数据
END
GO

-- 3. 验证账号
SELECT
    sp.name           AS 登录名,
    sp.is_disabled    AS 是否禁用,
    dp.name           AS 数据库用户,
    r.name            AS 数据库角色
FROM sys.server_principals sp
LEFT JOIN sys.database_principals dp ON sp.sid = dp.sid
LEFT JOIN sys.database_role_members rm ON dp.principal_id = rm.member_principal_id
LEFT JOIN sys.database_principals r ON rm.role_principal_id = r.principal_id
WHERE sp.name = 'CampusApp';
GO


SELECT name FROM sys.databases WHERE database_id > 4 ORDER BY name;

-- 连接字符串（发给成员 A 配到 appsettings.json）:
-- Server=10.135.22.61,1433;Database=CampusActivityDB;User Id=CampusApp;Password=111111;TrustServerCertificate=True
