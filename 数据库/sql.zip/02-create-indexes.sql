-- =============================================
-- 校园活动管理系统 - 索引优化
-- 成员C 第一周任务：查询性能优化
-- =============================================
-- 功能说明：
--   为 6 张核心表创建非聚集索引，优化高频查询性能
--   共计 14 个索引，覆盖以下查询场景：
--     - 用户按角色/手机号查询
--     - 活动按状态/类别/创建时间/创建者/截止时间查询
--     - 报名按用户/活动查询及人数统计
--     - 签到按用户/活动/报名记录/时间查询
--     - 黑名单按用户状态查询
-- =============================================
-- 索引设计原则：
--   1. 覆盖索引（INCLUDE）：将常用查询列加入索引，避免回表（Key Lookup）
--   2. 过滤索引（WHERE）：仅对特定子集建索引，减小索引体积
--   3. 复合索引：左前缀原则，将筛选频率高的列放在前面
--   4. 排序索引：对时间列使用 DESC 排序，匹配最新记录查询
--   5. 幂等性：使用 IF NOT EXISTS 确保脚本可重复执行
-- =============================================

USE CampusActivityDB;
GO


-- ============================================================
-- 一、Users 表索引（2个）
-- ============================================================

-- ----------------------------------------------------------
-- 索引 1: IX_Users_RoleId
-- 场景: 管理员查看某角色下的所有用户列表
-- 查询示例:
--   SELECT Username, RealName, IsActive
--   FROM Users WHERE RoleId = @RoleId;
-- 设计: 按 RoleId 筛选，INCLUDE 常用显示列避免回表
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_RoleId')
    CREATE NONCLUSTERED INDEX IX_Users_RoleId
    ON Users(RoleId)
    INCLUDE (Username, RealName, IsActive);

-- ----------------------------------------------------------
-- 索引 2: IX_Users_Phone（过滤索引）
-- 场景: 通过手机号查找用户（登录/找回密码/搜索）
-- 查询示例:
--   SELECT * FROM Users WHERE Phone = @Phone;
-- 设计: 过滤索引仅包含 Phone 非空的记录，减小索引体积
--       因为大部分学生可能不填手机号（NULL值不进入索引）
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_Phone')
    CREATE NONCLUSTERED INDEX IX_Users_Phone
    ON Users(Phone)
    WHERE Phone IS NOT NULL;


-- ============================================================
-- 二、Activities 表索引（5个）
-- ============================================================

-- ----------------------------------------------------------
-- 索引 3: IX_Activities_Status
-- 场景: 学生首页查看"进行中"或"未开始"的活动列表
-- 查询示例（最频繁的查询之一）:
--   SELECT Title, Category, Location, RegistrationDeadline, MaxParticipants, CreatedAt
--   FROM Activities WHERE Status = 0 ORDER BY CreatedAt DESC;
-- 设计: 覆盖索引，包含活动卡片展示所需的所有列
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Activities_Status')
    CREATE NONCLUSTERED INDEX IX_Activities_Status
    ON Activities(Status)
    INCLUDE (Title, Category, Location, RegistrationDeadline, MaxParticipants, CreatedAt);

-- ----------------------------------------------------------
-- 索引 4: IX_Activities_Category
-- 场景: 按活动类别筛选（学术/文体/社团分类浏览）
-- 查询示例:
--   SELECT Title, Status, RegistrationDeadline
--   FROM Activities WHERE Category = N'学术';
-- 设计: 轻量级覆盖索引，仅包含分类页面必要列
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Activities_Category')
    CREATE NONCLUSTERED INDEX IX_Activities_Category
    ON Activities(Category)
    INCLUDE (Title, Status, RegistrationDeadline);

-- ----------------------------------------------------------
-- 索引 5: IX_Activities_CreatedAt
-- 场景: 首页"最新活动"列表、按时间倒序浏览
-- 查询示例:
--   SELECT Title, Status, Category
--   FROM Activities ORDER BY CreatedAt DESC;
-- 设计: 索引键列使用 DESC 排序，直接匹配 ORDER BY 方向
--       INCLUDE 列用于列表显示，避免回表
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Activities_CreatedAt')
    CREATE NONCLUSTERED INDEX IX_Activities_CreatedAt
    ON Activities(CreatedAt DESC)
    INCLUDE (Title, Status, Category);

-- ----------------------------------------------------------
-- 索引 6: IX_Activities_CreatorUserId
-- 场景: 管理员查看自己发布的活动列表
-- 查询示例:
--   SELECT Title, Status, CreatedAt
--   FROM Activities WHERE CreatorUserId = @UserId;
-- 设计: 按创建者ID筛选，包含标题、状态、时间以便列表展示
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Activities_CreatorUserId')
    CREATE NONCLUSTERED INDEX IX_Activities_CreatorUserId
    ON Activities(CreatorUserId)
    INCLUDE (Title, Status, CreatedAt);

-- ----------------------------------------------------------
-- 索引 7: IX_Activities_RegistrationDeadline
-- 场景: 定时任务扫描到期的活动（自动切换活动状态）
-- 查询示例:
--   SELECT Status FROM Activities
--   WHERE RegistrationDeadline < GETDATE() AND Status = 0;
-- 设计: 仅包含 Status 列，用于后端定时任务快速查找需变更状态的活动
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Activities_RegistrationDeadline')
    CREATE NONCLUSTERED INDEX IX_Activities_RegistrationDeadline
    ON Activities(RegistrationDeadline)
    INCLUDE (Status);


-- ============================================================
-- 三、Registrations 表索引（3个）
-- ============================================================

-- ----------------------------------------------------------
-- 索引 8: IX_Registrations_UserId
-- 场景: "我的报名"列表（学生查看自己的所有报名记录）
-- 查询示例:
--   SELECT ActivityId, RegistrationTime
--   FROM Registrations WHERE UserId = @UserId AND Status = 0;
-- 设计: 复合索引（UserId + Status），先按用户筛选再按状态过滤
--       INCLUDE ActivityId 和 RegistrationTime 用于列表展示
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Registrations_UserId')
    CREATE NONCLUSTERED INDEX IX_Registrations_UserId
    ON Registrations(UserId, Status)
    INCLUDE (ActivityId, RegistrationTime);

-- ----------------------------------------------------------
-- 索引 9: IX_Registrations_ActivityId
-- 场景: 管理员查看某活动的报名名单
-- 查询示例:
--   SELECT UserId, RegistrationTime
--   FROM Registrations WHERE ActivityId = @ActivityId AND Status = 0;
-- 设计: 复合索引（ActivityId + Status），方便按活动导出报名名单
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Registrations_ActivityId')
    CREATE NONCLUSTERED INDEX IX_Registrations_ActivityId
    ON Registrations(ActivityId, Status)
    INCLUDE (UserId, RegistrationTime);

-- ----------------------------------------------------------
-- 索引 10: IX_Registrations_ActivityId_Count（过滤索引）
-- 场景: 统计某活动的报名人数（活动热度、满员判断）
-- 查询示例:
--   SELECT COUNT(*) FROM Registrations
--   WHERE ActivityId = @ActivityId AND Status = 0;
-- 设计: 过滤索引仅包含有效报名（Status=0），大幅减少索引扫描范围
--       不需要 INCLUDE 列，因为 COUNT(*) 只统计行数
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Registrations_ActivityId_Count')
    CREATE NONCLUSTERED INDEX IX_Registrations_ActivityId_Count
    ON Registrations(ActivityId)
    WHERE Status = 0;


-- ============================================================
-- 四、CheckIns 表索引（4个）
-- ============================================================

-- ----------------------------------------------------------
-- 索引 11: IX_CheckIns_UserId
-- 场景: "我的签到记录"（学生查看自己的签到历史）
-- 查询示例:
--   SELECT ActivityId, CheckInTime, CheckInType
--   FROM CheckIns WHERE UserId = @UserId;
-- 设计: 复合索引（UserId + ActivityId），按用户+活动分组查询
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_CheckIns_UserId')
    CREATE NONCLUSTERED INDEX IX_CheckIns_UserId
    ON CheckIns(UserId, ActivityId)
    INCLUDE (CheckInTime, CheckInType);

-- ----------------------------------------------------------
-- 索引 12: IX_CheckIns_ActivityId
-- 场景: 活动签到统计（管理员查看某活动签到情况，计算签到率）
-- 查询示例:
--   SELECT UserId, CheckInTime, CheckInType
--   FROM CheckIns WHERE ActivityId = @ActivityId;
-- 设计: 覆盖索引，包含签到统计所需的核心字段
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_CheckIns_ActivityId')
    CREATE NONCLUSTERED INDEX IX_CheckIns_ActivityId
    ON CheckIns(ActivityId)
    INCLUDE (UserId, CheckInTime, CheckInType);

-- ----------------------------------------------------------
-- 索引 13: IX_CheckIns_RegistrationId（过滤索引）
-- 场景: 扫码签到时校验是否已签到（防止重复签到）
-- 查询示例:
--   SELECT CheckInId FROM CheckIns
--   WHERE RegistrationId = @RegId;
-- 设计: 过滤索引仅包含有报名关联的记录（扫码签到），排除补签
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_CheckIns_RegistrationId')
    CREATE NONCLUSTERED INDEX IX_CheckIns_RegistrationId
    ON CheckIns(RegistrationId)
    WHERE RegistrationId IS NOT NULL;

-- ----------------------------------------------------------
-- 索引 14: IX_CheckIns_CheckInTime
-- 场景: 查询最近的签到记录（实时签到播报大屏）
-- 查询示例:
--   SELECT TOP 20 UserId, ActivityId, CheckInTime
--   FROM CheckIns ORDER BY CheckInTime DESC;
-- 设计: 索引键列使用 DESC 排序，匹配"最近签到"查询
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_CheckIns_CheckInTime')
    CREATE NONCLUSTERED INDEX IX_CheckIns_CheckInTime
    ON CheckIns(CheckInTime DESC)
    INCLUDE (UserId, ActivityId);


-- ============================================================
-- 五、Blacklist 表索引（1个）
-- ============================================================

-- ----------------------------------------------------------
-- 索引 15: IX_Blacklist_UserId
-- 场景: 报名/签到前检查用户是否在黑名单中（高频校验查询）
-- 查询示例:
--   SELECT ActivityId, Reason FROM Blacklist
--   WHERE UserId = @UserId AND IsActive = 1
--     AND (ActivityId = @ActivityId OR ActivityId IS NULL);
-- 设计: 复合索引（UserId + IsActive），先按用户筛选再按生效状态过滤
--       INCLUDE ActivityId 和 Reason 用于判断拉黑范围和显示原因
-- ----------------------------------------------------------
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Blacklist_UserId')
    CREATE NONCLUSTERED INDEX IX_Blacklist_UserId
    ON Blacklist(UserId, IsActive)
    INCLUDE (ActivityId, Reason);


-- 打印完成信息
PRINT N'============================================';
PRINT N'  所有索引创建完成！';
PRINT N'  共创建 14 个非聚集索引：';
PRINT N'    Users:        2  (RoleId, Phone)';
PRINT N'    Activities:   5  (Status, Category, CreatedAt, CreatorUserId, RegistrationDeadline)';
PRINT N'    Registrations: 3  (UserId, ActivityId, ActivityId过滤)';
PRINT N'    CheckIns:     4  (UserId, ActivityId, RegistrationId过滤, CheckInTime)';
PRINT N'    Blacklist:    1  (UserId+IsActive)';
PRINT N'============================================';
GO
