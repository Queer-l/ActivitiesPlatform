-- =============================================
-- 校园活动管理系统 - 报名名单导出查询
-- 成员C：文件与数据管理（Excel/CSV 导出）
-- =============================================
-- 用途：
--   1. 为后端 / WinForm 导出 Excel、CSV 提供标准查询字段
--   2. 支持 SQL Server Management Studio 直接执行后另存为 CSV
--   3. 支持 sqlcmd 命令行导出
-- =============================================

USE CampusActivityDB;
GO

DECLARE @ActivityId INT = 1; -- 修改为要导出的活动ID

SELECT
    a.ActivityId                         AS ActivityId,
    a.Title                              AS ActivityTitle,
    u.UserId                             AS UserId,
    u.Username                           AS Username,
    u.RealName                           AS RealName,
    u.Email                              AS Email,
    u.Phone                              AS Phone,
    r.RegistrationTime                   AS RegistrationTime,
    CASE r.Status
        WHEN 0 THEN N'已报名'
        WHEN 1 THEN N'已取消'
        ELSE N'未知'
    END                                  AS RegistrationStatus,
    CASE WHEN ci.CheckInId IS NULL THEN N'否' ELSE N'是' END AS HasCheckedIn,
    ci.CheckInTime                       AS CheckInTime,
    CASE ci.CheckInType
        WHEN 0 THEN N'扫码签到'
        WHEN 1 THEN N'手动补签'
        ELSE NULL
    END                                  AS CheckInType
FROM Registrations r
JOIN Users u ON r.UserId = u.UserId
JOIN Activities a ON r.ActivityId = a.ActivityId
LEFT JOIN CheckIns ci
    ON ci.UserId = r.UserId
   AND ci.ActivityId = r.ActivityId
WHERE r.ActivityId = @ActivityId
ORDER BY r.RegistrationTime DESC, u.UserId ASC;
GO

-- 命令行导出示例（PowerShell / CMD 中执行，按实际服务器修改 -S）：
-- sqlcmd -S localhost -d CampusActivityDB -E -W -s "," -f 65001 -Q "SET NOCOUNT ON; SELECT a.ActivityId AS ActivityId,a.Title AS ActivityTitle,u.UserId,u.Username,u.RealName,u.Email,u.Phone,r.RegistrationTime,CASE r.Status WHEN 0 THEN N'已报名' WHEN 1 THEN N'已取消' ELSE N'未知' END AS RegistrationStatus,CASE WHEN ci.CheckInId IS NULL THEN N'否' ELSE N'是' END AS HasCheckedIn,ci.CheckInTime,CASE ci.CheckInType WHEN 0 THEN N'扫码签到' WHEN 1 THEN N'手动补签' ELSE NULL END AS CheckInType FROM Registrations r JOIN Users u ON r.UserId=u.UserId JOIN Activities a ON r.ActivityId=a.ActivityId LEFT JOIN CheckIns ci ON ci.UserId=r.UserId AND ci.ActivityId=r.ActivityId WHERE r.ActivityId=1 ORDER BY r.RegistrationTime DESC,u.UserId ASC;" -o registrations_activity_1.csv
